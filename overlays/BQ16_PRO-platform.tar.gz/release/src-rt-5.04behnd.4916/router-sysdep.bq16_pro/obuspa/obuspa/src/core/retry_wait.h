/*
 *
 * Copyright (C) 2019, Broadband Forum
 * Copyright (C) 2018-2019  CommScope, Inc
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived from
 *    this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/**
 * \file retry_wait.h
 *
 * Calculates a time to wait between retries according to the standard TR069 algorithm, detailed in:-
 *     TR-069 Section 3.2.1.1 Session Retry
 *     TR-157 Section A.2.2.1
 *
 * This algorithm is used for :-
 *     STOMP connection retries
 *     bulk data collection post retries
 *     subscription notification retries
 *
 */

#ifndef RETRY_WAIT_H
#define RETRY_WAIT_H 1

unsigned RETRY_WAIT_Calculate(unsigned retry_count, double m, double k);

//----------------------------------------------------
// Random number generator seeds used by each thread
extern unsigned dm_thread_random_seed;
extern unsigned mtp_thread_random_seed;

//----------------------------------------------------
// API
void RETRY_WAIT_Init(void);
unsigned RETRY_WAIT_Calculate(unsigned retry_count, double m, double k);
time_t RETRY_WAIT_UseRandomBaseIfUnknownTime(time_t base);

#endif
