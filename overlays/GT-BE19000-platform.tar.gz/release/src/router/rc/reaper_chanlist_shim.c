/* SPDX-License-Identifier: GPL-2.0-only
 * Reaper GT-BE19000 prebuilt-compat shim.
 *
 * The closed per-model objects rc/broadcom.o, rc/private.o, shared/spwenc.o
 * and shared/nvpriv.o are the official ASUS GT-BE19000 GPL 102_39274 builds,
 * taken from that drop and nothing else. They are model-correct, but they
 * predate three helpers that our 3006.102.8-level open source links against.
 * Verified with the cross toolchain's nm on the drop's own objects
 * (2026-09-10): wl_scb, backup_eth_ob_log and is_wan_port_ext_switch are
 * absent; ed_thresh_clear is present, so no channel-list delegate is needed.
 *
 * Each stub below reproduces the behavior of ASUS's own firmware at 39274,
 * which had no such symbol and therefore no such branch:
 *
 * - wl_scb(): an rc diagnostic applet dispatch added in the .8 line
 *   (rc.c "wl_scb" busybox-style applet). No-op here; the applet simply
 *   reports nothing, exactly like stock 39274.
 * - backup_eth_ob_log(): watchdog's AiMesh onboarding-timeout path backs up
 *   an onboarding log right before notify_rc("resetdefault"). Skipping the
 *   backup loses only that diagnostic file; the reset path is unchanged.
 * - is_wan_port_ext_switch(): gates a MULTISERVICE_WAN STB auto-bridge
 *   branch in interface.c. Returning 0 selects the generic path - and this
 *   board's target.mak does not set MULTISERVICE_WAN at all, so the branch
 *   is never reached.
 *
 * rc/Makefile picks this file up by wildcard; delete it and the link fails
 * loudly on the three symbols above, which is the correct failure.
 *
 * Same shape as the GT-BE98's shim: both boards ship 39274-era closed
 * objects against the same 102.8 source, so both are missing the same three.
 */

void wl_scb(void)
{
	/* not provided by the GT-BE19000 102_39274 prebuilt; nothing to report */
}

int backup_eth_ob_log(void)
{
	return 0;
}

int is_wan_port_ext_switch(int base_unit)
{
	(void)base_unit;
	return 0;
}
