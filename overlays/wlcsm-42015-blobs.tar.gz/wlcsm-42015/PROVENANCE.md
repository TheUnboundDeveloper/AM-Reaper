# WLCSM socket-leak fix: blobs extracted from ASUS stock GT-BE98_PRO 9.0.0.6_102_42015

Source image : GT-BE98_PRO_9.0.0.6_102_42015-g73e87ed_1592-g6178c_BB0B_nand_squashfs.pkgtb
Image sha256 : 812986587030f60ce4f47fceea520c265451a8622122ff84346f32605199b088
build_time   : 西元2026年08月21日 (週五) 18時05分34秒 CST
image_version: 5044p3GW2331805(BSPv1W13)
Extracted    : 2026-09-16T13:37:09-04:00 by unsquashfs of the FIT nand_squashfs image (offset 0xcace64)

## Files (stock, stripped as shipped)

- libnvram.so    35916 B  sha256 fc74fe87b94e85158d31b6a7257348ac99223d3524ebb353ffea1f07ad44da88
- libwlcsm.so    46708 B  sha256 a618dbf02eff5f6a38744a5e6702b3cb02da8690bda191bc29efe36c6b34b6a5

## Ours (staged v3.1.8_BETA_r2, same BSP 5.04L.04_P3 / BSPv1W13)

- libnvram.so    35912 B  sha256 6eb214a9e4de1269d5467c8ac5d9f3ed4fdfda535d6546ea222fba44d0e35c46
- libwlcsm.so    46700 B  sha256 8e3f29346e31b0929c5df3553695e92bbc618c1a7a66f92f3edd5f31bb417759
- /bin/nvram   : byte-identical to ours (sha 7ea7de4161b9b5e7) - the fix is NOT in nvram.c

## What changed (disassembly deltas in evidence/)

- _wlcsm_init (both libs): 444 -> 532 B. On re-init the three tracked fds are close()d and set to -1 (the re-init fd leak, bug B);
  the saved PID stays at wlcsm_agent+24 while the allocator gets a NEW candidate field at +28 (the aliasing, bug A) - wlcsm_agent 32 -> 36 B;
  the post-allocator error path closes what it opened; -fstack-protector added; __LINE__ in the init-failed message 410 -> 461.
- _wlcsm_netlink_send_mesg: reads the netlink port from +28 (was +24). Size unchanged.
- libwlcsm.so wlcsm_nvram_getall: 320 -> 360 B, now calls usleep (backoff in the retry loop); wlcsm_nvram_get 292 -> 300 B.
- The 10-slot allocator (mov r7,#10) is unchanged.

## Applicability

- wlcsm_agent is defined by libnvram.so and imported ONLY by libwlcsm.so: swap BOTH together, never one.
- strip(our unstripped prebuilt) == our staged lib byte-for-byte, so the swap path is: replace
  router-sysdep.rt-be96u/wlan/nvram/prebuilt/libnvram.so and router-sysdep.rt-be96u/wlcsm/prebuilt/libwlcsm.so with these (already stripped; the build's strip is a no-op).
- Provenance: ASUS's publicly distributed firmware, same Broadcom BSP as our base. This is a vendor blob SWAP, not a binary patch (scope rule: never modify a blob).
- Reaper's wlcsm_bindfix (LD_PRELOAD bind() interposer, nvram wlcsm_bindfix=1) is ABI-independent and coexists; it becomes belt-and-braces once the fixed blobs ship.
- Regression test: reproducer bundle wlscm-debug-reproducer-9.0.0.6_102_42015 (10 forced-collision runs, expect rc=0, no X+1..X+9 accumulation).
